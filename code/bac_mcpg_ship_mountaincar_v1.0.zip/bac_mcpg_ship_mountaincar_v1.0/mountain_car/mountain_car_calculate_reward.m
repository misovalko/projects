function reward = mountain_car_calculate_reward(state,~,~)
reward = state.isgoal - 1;
return
