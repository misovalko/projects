% MCPG
%
% @article{ghavamzadeh2016bayesian,
% abstract = {Policy gradient methods are reinforcement learning algorithms that adapt a parameterized policy by following a performance gradient estimate. Many conventional policy gradient methods use Monte-Carlo techniques to estimate this gradient. The policy is improved by adjusting the parameters in the direction of the gradient estimate. Since Monte-Carlo methods tend to have high variance, a large number of samples is required to attain accurate estimates, resulting in slow convergence. In this paper, we first propose a Bayesian framework for policy gradient, based on modeling the policy gradient as a Gaussian process. This reduces the number of samples needed to obtain accurate gradient estimates. Moreover, estimates of the natural gradient as well as a measure of the uncertainty in the gradient estimates, namely, the gradient covariance, are provided at little extra cost. Since the proposed Bayesian framework considers system trajectories as its basic observable unit, it does not require the dynamics within trajectories to be of any particular form, and thus, can be easily extended to partially observable problems. On the downside, it cannot take advantage of the Markov property when the system is Markovian. To address this issue, we proceed to supplement our Bayesian policy gradient framework with a new actor-critic learning model in which a Bayesian class of non-parametric critics, based on Gaussian process temporal difference learning, is used. Such critics model the action-value function as a Gaussian process, allowing Bayes' rule to be used in computing the posterior distribution over action-value functions, conditioned on the observed data. Appropriate choices of the policy parameterization and of the prior covariance (kernel) between action-values allow us to obtain closed-form expressions for the posterior distribution of the gradient of the expected return with respect to the policy parameters. We perform detailed experimental comparisons of the proposed Bayesian policy gradient and actor-critic algorithms with classic Monte-Carlo based policy gradient methods, as well as with each other, on a number of reinforcement learning problems.},
% author = {Ghavamzadeh, Mohammad and Engel, Yaakov and Valko, Michal},
% journal = {Journal of Machine Learning Research},
% title = {{Bayesian policy gradient and actor-critic algorithms}},
% year = {2016}
% }


function [perf,theta] = mcpg(d,learning_params)
%% initialization
learning_params.num_output = (learning_params.num_update_max / learning_params.sample_interval) + 1;
perf = zeros(learning_params.num_trial,learning_params.num_output);

if ~isfield(d,'STEP')
    d.STEP = 1;
end
%%

for i = 1:learning_params.num_trial
    
    exptime = now;
    tic
    
    exp_dir_name = strcat('results/',learning_params.other_name,'/');
    mkdir(exp_dir_name);
    filename = sprintf('%s MCPG - %s -%d', d.name,datestr(exptime,30),randi(1e5));
    fid1 = fopen(strcat(exp_dir_name,filename,'.txt'),'a+');
    fclose(fid1);
    
    alp = learning_params.alp_init_MC;
    theta = zeros(d.num_policy_param,1);
    for j = 1:(learning_params.num_update_max+1)
        if ~mod(j,50)
            fprintf('Trial %d, Update %d\n',i, j);
        end
        DELTA = zeros(d.num_policy_param,1);
        T = 0;
        if (mod(j-1,learning_params.sample_interval) == 0)
            toc
            evalpoint =floor(j/learning_params.sample_interval)+1;
            perf(i,evalpoint) = d.perf_eval(theta,d,learning_params);
            
            fid1 = fopen(strcat(exp_dir_name,filename,'.txt'),'a+');
            fprintf(fid1,'%d,%f\n',j-1, perf(i,floor(j/learning_params.sample_interval)+1));
            fclose(fid1);
            
            tic
        end
        for l = 1:learning_params.num_episode
            t = 0;
            scr_path_sum = zeros(d.num_policy_param,1);
            state = d.random_state(d);
            [a, ~] = d.calc_score(theta, state,d,learning_params);
            while (~state.isgoal && t < learning_params.episode_len_max)
                for istep = 1:d.STEP
                    if (state.isgoal==0)
                        [state,~] = d.dynamics(state,a,d);
                        state = d.is_goal(state,d);
                    end
                end
                [a, scr] = d.calc_score(theta, state, d,learning_params);
                scr_path_sum = scr_path_sum + scr;
                r =  d.calculate_reward(state,a,d);
                DELTA = DELTA + (r * scr_path_sum);
                t = t + 1;
            end
            T = T + t;
        end
        grad_MC = DELTA;
        theta = theta + (alp * grad_MC);
        
    end
end



