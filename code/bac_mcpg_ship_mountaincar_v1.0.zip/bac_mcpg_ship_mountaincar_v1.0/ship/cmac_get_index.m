function index = cmac_get_index(tiling,x)

if(numel(x) ~= numel(tiling.cut))    
    fprintf(1,'Tiling error: invalid vector size = %d\n', numel(x));
    error('exit');
end


index=0;
k=1;
range = (tiling.ilist(1).upper - tiling.ilist(1).lower);
tiling.cut_size = range/double(tiling.cut(1));
r = x(1) - (tiling.offset(1) + tiling.ilist(1).lower);

if(r < 0 || r >= range)
    index = -1;
    return;
end

index = index + floor(r/tiling.cut_size);

for i=2:numel(tiling.cut); 
    k = k*tiling.cut(i-1);
    range = (tiling.ilist(i).upper - tiling.ilist(i).lower);
    tiling.cut_size = range/double(tiling.cut(i));
    r = x(i) - (tiling.offset(i) + tiling.ilist(i).lower);
    if(r < 0 || r >= range)
        index = -1;
        return;
    end
    index = index + floor(r/tiling.cut_size) * k;
end
if(index < 0 || index >= prod(tiling.cut))
    fprintf(1,'Tiling error: invalid index %d, out of bound (num_tiles = %d)\n', numel(x), num_tiles);
    error('exit');
end



