function [act, scr, domain_params] = ship_calc_score(theta,state,domain_params,learning_params)
% chooses the next action and calculates the Fisher information score for the ship domain
% INPUT
%   theta: current feature weights

%% calculate the features values from the state
% converts the state into 1D vector (vin)
vin(1) = state.x;
vin(2) = state.y;
vin(3) = state.theta;
vin(4) = state.dot_theta;

flist = cmac_tiling_map(vin, domain_params.tiling_set,domain_params.svar);

%% choose an action

mu_sum = 0;
features = zeros(size(theta));

for i=1:numel(flist)
    % basic setting and checks
    tnum = flist(i).tnum;
    if isempty(tnum), continue, end;
    if ((tnum < 1) || (tnum > learning_params.NUM_TILINGS))
        fprintf(1, 'error: invalid tiling number (%d) ...\n', tnum);
        error('exit');
    end
    tindex = flist(i).tindex;
    if ((tindex < 0) || (tindex >= learning_params.num_tiles))
        fprintf(1, 'error: invalid tile index (%d) ...\n', tindex);
        error('exit');
    end
    
    theta_tile = theta((tnum-1)*learning_params.num_tiles+1:tnum*learning_params.num_tiles);
    mu_sum = mu_sum + theta_tile(tindex+1); % tiles are indexed from 0!!
    features((tnum-1)*learning_params.num_tiles + tindex+1) = 1; % tiles are indexed from 0!!
end

mu = mu_sum / numel(flist);

% choose action and calculate the score
action = normrnd(mu, learning_params.SIGMA_INIT);


act = domain_params.R_MAX * (2 / pi) * atan((pi * action * 1) / 2);

update = (action - mu) / (learning_params.SIGMA_INIT *learning_params.SIGMA_INIT * numel(flist)); 

if (act > domain_params.R_MAX)
    act = domain_params.R_MAX;
elseif (act < -domain_params.R_MAX)
    act = -domain_params.R_MAX;
end


%% update_Z  (only useful for policy gradient)
if isfield(learning_params,'calculate_eligibilities') && learning_params.calculate_eligibilities;        
    for i=1:numel(flist)
        % basic setting and checks
        tnum = flist(i).tnum;
        if isempty(tnum), continue, end;
        if ((tnum < 1) || (tnum > learning_params.NUM_TILINGS))
            fprintf(1, 'error: invalid tiling number (%d) ...\n', tnum);
            error('exit');
        end
        tindex = flist(i).tindex;
        if ((tindex < 0) || (tindex > learning_params.num_tiles))
            fprintf(1, 'error: invalid tile index (%d) ...\n', tindex);
            error('exit');
        end
        domain_params.tiling_set(tnum).z(tindex+1) = domain_params.tiling_set(tnum).z(tindex+1) + update;
    end
end

%% calculate the score...
scr = update * features;

end