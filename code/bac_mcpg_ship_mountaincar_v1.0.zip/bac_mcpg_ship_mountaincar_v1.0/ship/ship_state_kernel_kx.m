function kx= ship_state_kernel_kx( state, statedic, domain_params )

scale = abs(domain_params.range(:,1) - domain_params.range(:,2));

% putting all states current + dic into a single array
s = zeros(numel(statedic) + 1,4);
s(:,1) = [state.x statedic.x];
s(:,2) = [state.y statedic.y];
s(:,3) = [state.theta statedic.theta];
s(:,4) = [state.dot_theta statedic.dot_theta];
s(:,5) = [state.V statedic.V];


%% calculation of ang:
x_goal = domain_params.X_INIT + domain_params.DELTA_X;
y_goal = domain_params.Y_INIT + domain_params.DELTA_Y;
ang = (s(:,3) * pi) / 180;
x_new = s(:,1) + (domain_params.DELTA_T * s(:,5) .* sin(ang));
y_new = s(:,2) + (domain_params.DELTA_T * s(:,5) .* cos(ang));
ang1 = atan2((s(:,2) - y_goal), (s(:,1) - x_goal));
ang2 = atan2((s(:,2) - y_new),(s(:,1) - x_new));
ang = ang1-ang2;  
ang(ang>pi) = ang(ang>pi) - 2*pi;
ang(ang<-pi) = ang(ang<-pi) + 2*pi;


% scaling
s(:,1) = (s(:,1) - domain_params.range(1,1)) / scale(1);
s(:,2) = (s(:,2) - domain_params.range(2,1)) / scale(2);
s(:,3) = (ang+pi)/(2*pi);
s(:,4) = (s(:,4) - domain_params.range(4,1)) / scale(4);
finalstate = [s(:,1) s(:,2) s(:,3) s(:,4)];
d = pdist2octave(finalstate(1,:),finalstate(2:end,:),'euclidean');
sigk_x = 1;
kx = exp(-(d.^2)/(2*sigk_x*sigk_x));



end


