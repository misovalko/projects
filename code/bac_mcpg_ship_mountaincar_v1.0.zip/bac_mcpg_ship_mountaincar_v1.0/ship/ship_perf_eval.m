function perf = ship_perf_eval(theta,domain_params,learning_params)
num_success = 0;

for l = 1:domain_params.num_episode_eval
    t = 0;
    state = domain_params.random_state(domain_params);
    [a, ~] = domain_params.calc_score(theta,state,domain_params,learning_params);
    while (state.isgoal == 0 && t < learning_params.episode_len_max)
        for istep = 1:domain_params.STEP
            if (state.isgoal==0)
                [state,~] = domain_params.dynamics(state,a,domain_params);
                state = domain_params.is_goal(state,domain_params);
            end
        end
        [a, ~] = domain_params.calc_score(theta, state, domain_params,learning_params);
        t = t + 1;
        
        if sum(theta)~=0
           ship_draw(state,domain_params,[]);
        end
       
        if state.isgoal && state.success
            num_success = num_success + 1;
        end
    end 
end 

perf = num_success / domain_params.num_episode_eval;
end