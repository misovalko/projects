learning_params.NUM_TILINGS = 9;


cut4 = [5, 5, 36, 5];

domain_params.num_policy_param = learning_params.NUM_TILINGS*cut4(1)*cut4(2)*cut4(3)*cut4(4);


% tilings 
range(1,1) = domain_params.X_MIN;         
range(1,2) = domain_params.X_MAX;         %-- x changes between (0,150)
range(2,1) = domain_params.Y_MIN;         
range(2,2) = domain_params.Y_MAX;         %--- y changes between (0,150)
range(3,1) = domain_params.THETA_MIN;     
range(3,2) = domain_params.THETA_MAX;     %--- theta changes between (-180,180)
range(4,1) = domain_params.DOT_THETA_MIN;    
range(4,2) = domain_params.DOT_THETA_MAX;    %--- dtheta/dt changes between (-15,15)

domain_params.range = range;

% Tiling t_4D_grid_0(num_tiles, dim, W0, Z0);
t_4D_grid_0.cut(1)         = cut4(1);
t_4D_grid_0.cut(2)         = cut4(2);
t_4D_grid_0.cut(3)         = cut4(3);
t_4D_grid_0.cut(4)         = cut4(4);
t_4D_grid_0.offset(1)      = 0;
t_4D_grid_0.offset(2)      = 0;
t_4D_grid_0.offset(3)      = 0;
t_4D_grid_0.offset(4)      = 0;
t_4D_grid_0.ilist(1).lower = range(1,1);
t_4D_grid_0.ilist(1).upper = range(1,2);
t_4D_grid_0.ilist(2).lower = range(2,1);
t_4D_grid_0.ilist(2).upper = range(2,2);
t_4D_grid_0.ilist(3).lower = range(3,1);
t_4D_grid_0.ilist(3).upper = range(3,2);
t_4D_grid_0.ilist(4).lower = range(4,1);
t_4D_grid_0.ilist(4).upper = range(4,2);
domain_params.tiling_set(1) = t_4D_grid_0;

% Tiling t_4D_grid_1(num_tiles, dim, W0, Z0);
t_4D_grid_1.cut(1)         = cut4(1);
t_4D_grid_1.cut(2)         = cut4(2);
t_4D_grid_1.cut(3)         = cut4(3);
t_4D_grid_1.cut(4)         = cut4(4);
t_4D_grid_1.offset(1)      = 24;
t_4D_grid_1.offset(2)      = 18;
t_4D_grid_1.offset(3)      = 5;
t_4D_grid_1.offset(4)      = 4;
t_4D_grid_1.ilist(1).lower = range(1,1);
t_4D_grid_1.ilist(1).upper = range(1,2);
t_4D_grid_1.ilist(2).lower = range(2,1);
t_4D_grid_1.ilist(2).upper = range(2,2);
t_4D_grid_1.ilist(3).lower = range(3,1);
t_4D_grid_1.ilist(3).upper = range(3,2);
t_4D_grid_1.ilist(4).lower = range(4,1);
t_4D_grid_1.ilist(4).upper = range(4,2);
domain_params.tiling_set(2) = t_4D_grid_1;

% Tiling t_4D_grid_2(num_tiles, dim, W0, Z0);
t_4D_grid_2.cut(1)         = cut4(1);
t_4D_grid_2.cut(2)         = cut4(2);
t_4D_grid_2.cut(3)         = cut4(3);
t_4D_grid_2.cut(4)         = cut4(4);
t_4D_grid_2.offset(1)      = 12;
t_4D_grid_2.offset(2)      = 24;
t_4D_grid_2.offset(3)      = 6;
t_4D_grid_2.offset(4)      = -3;
t_4D_grid_2.ilist(1).lower = range(1,1);
t_4D_grid_2.ilist(1).upper = range(1,2);
t_4D_grid_2.ilist(2).lower = range(2,1);
t_4D_grid_2.ilist(2).upper = range(2,2);
t_4D_grid_2.ilist(3).lower = range(3,1);
t_4D_grid_2.ilist(3).upper = range(3,2);
t_4D_grid_2.ilist(4).lower = range(4,1);
t_4D_grid_2.ilist(4).upper = range(4,2);
domain_params.tiling_set(3) = t_4D_grid_2;

% Tiling t_4D_grid_3(num_tiles, dim, W0, Z0);
t_4D_grid_3.cut(1)         = cut4(1);
t_4D_grid_3.cut(2)         = cut4(2);
t_4D_grid_3.cut(3)         = cut4(3);
t_4D_grid_3.cut(4)         = cut4(4);
t_4D_grid_3.offset(1)      = 12;
t_4D_grid_3.offset(2)      = 18;
t_4D_grid_3.offset(3)      = -8;
t_4D_grid_3.offset(4)      = 5;
t_4D_grid_3.ilist(1).lower = range(1,1);
t_4D_grid_3.ilist(1).upper = range(1,2);
t_4D_grid_3.ilist(2).lower = range(2,1);
t_4D_grid_3.ilist(2).upper = range(2,2);
t_4D_grid_3.ilist(3).lower = range(3,1);
t_4D_grid_3.ilist(3).upper = range(3,2);
t_4D_grid_3.ilist(4).lower = range(4,1);
t_4D_grid_3.ilist(4).upper = range(4,2);
domain_params.tiling_set(4) = t_4D_grid_3;

% Tiling t_4D_grid_4(num_tiles, dim, W0, Z0);
t_4D_grid_4.cut(1)         = cut4(1);
t_4D_grid_4.cut(2)         = cut4(2);
t_4D_grid_4.cut(3)         = cut4(3);
t_4D_grid_4.cut(4)         = cut4(4);
t_4D_grid_4.offset(1)      = 24;
t_4D_grid_4.offset(2)      = 12;
t_4D_grid_4.offset(3)      = -4;
t_4D_grid_4.offset(4)      = -2;
t_4D_grid_4.ilist(1).lower = range(1,1);
t_4D_grid_4.ilist(1).upper = range(1,2);
t_4D_grid_4.ilist(2).lower = range(2,1);
t_4D_grid_4.ilist(2).upper = range(2,2);
t_4D_grid_4.ilist(3).lower = range(3,1);
t_4D_grid_4.ilist(3).upper = range(3,2);
t_4D_grid_4.ilist(4).lower = range(4,1);
t_4D_grid_4.ilist(4).upper = range(4,2);
domain_params.tiling_set(5) = t_4D_grid_4;

% Tiling t_4D_grid_5(num_tiles, dim, W0, Z0);
t_4D_grid_5.cut(1)         = cut4(1);
t_4D_grid_5.cut(2)         = cut4(2);
t_4D_grid_5.cut(3)         = cut4(3);
t_4D_grid_5.cut(4)         = cut4(4);
t_4D_grid_5.offset(1)      = -12;
t_4D_grid_5.offset(2)      = -12;
t_4D_grid_5.offset(3)      = 8;
t_4D_grid_5.offset(4)      = 3;
t_4D_grid_5.ilist(1).lower = range(1,1);
t_4D_grid_5.ilist(1).upper = range(1,2);
t_4D_grid_5.ilist(2).lower = range(2,1);
t_4D_grid_5.ilist(2).upper = range(2,2);
t_4D_grid_5.ilist(3).lower = range(3,1);
t_4D_grid_5.ilist(3).upper = range(3,2);
t_4D_grid_5.ilist(4).lower = range(4,1);
t_4D_grid_5.ilist(4).upper = range(4,2);
domain_params.tiling_set(6) = t_4D_grid_5;

% Tiling t_4D_grid_6(num_tiles, dim, W0, Z0);
t_4D_grid_6.cut(1)         = cut4(1);
t_4D_grid_6.cut(2)         = cut4(2);
t_4D_grid_6.cut(3)         = cut4(3);
t_4D_grid_6.cut(4)         = cut4(4);
t_4D_grid_6.offset(1)      = -18;
t_4D_grid_6.offset(2)      = -24;
t_4D_grid_6.offset(3)      = 6;
t_4D_grid_6.offset(4)      = -4;
t_4D_grid_6.ilist(1).lower = range(1,1);
t_4D_grid_6.ilist(1).upper = range(1,2);
t_4D_grid_6.ilist(2).lower = range(2,1);
t_4D_grid_6.ilist(2).upper = range(2,2);
t_4D_grid_6.ilist(3).lower = range(3,1);
t_4D_grid_6.ilist(3).upper = range(3,2);
t_4D_grid_6.ilist(4).lower = range(4,1);
t_4D_grid_6.ilist(4).upper = range(4,2);
domain_params.tiling_set(7) = t_4D_grid_6;

% Tiling t_4D_grid_7(num_tiles, dim, W0, Z0);
t_4D_grid_7.cut(1)         = cut4(1);
t_4D_grid_7.cut(2)         = cut4(2);
t_4D_grid_7.cut(3)         = cut4(3);
t_4D_grid_7.cut(4)         = cut4(4);
t_4D_grid_7.offset(1)      = -24;
t_4D_grid_7.offset(2)      = -12;
t_4D_grid_7.offset(3)      = -5;
t_4D_grid_7.offset(4)      = 4;
t_4D_grid_7.ilist(1).lower = range(1,1);
t_4D_grid_7.ilist(1).upper = range(1,2);
t_4D_grid_7.ilist(2).lower = range(2,1);
t_4D_grid_7.ilist(2).upper = range(2,2);
t_4D_grid_7.ilist(3).lower = range(3,1);
t_4D_grid_7.ilist(3).upper = range(3,2);
t_4D_grid_7.ilist(4).lower = range(4,1);
t_4D_grid_7.ilist(4).upper = range(4,2);
domain_params.tiling_set(8) = t_4D_grid_7;

% Tiling t_4D_grid_8(num_tiles, dim, W0, Z0);
t_4D_grid_8.cut(1)         = cut4(1);
t_4D_grid_8.cut(2)         = cut4(2);
t_4D_grid_8.cut(3)         = cut4(3);
t_4D_grid_8.cut(4)         = cut4(4);
t_4D_grid_8.offset(1)      = -18;
t_4D_grid_8.offset(2)      = -12;
t_4D_grid_8.offset(3)      = -8;
t_4D_grid_8.offset(4)      = -3;
t_4D_grid_8.ilist(1).lower = range(1,1);
t_4D_grid_8.ilist(1).upper = range(1,2);
t_4D_grid_8.ilist(2).lower = range(2,1);
t_4D_grid_8.ilist(2).upper = range(2,2);
t_4D_grid_8.ilist(3).lower = range(3,1);
t_4D_grid_8.ilist(3).upper = range(3,2);
t_4D_grid_8.ilist(4).lower = range(4,1);
t_4D_grid_8.ilist(4).upper = range(4,2);
domain_params.tiling_set(9) = t_4D_grid_8;

learning_params.num_tiles = prod(cut4);
[domain_params.tiling_set(:).z] = deal(zeros(learning_params.num_tiles,1));


svar = repmat([4 1:4],9,1);

domain_params.svar = svar;

clear t_4D_grid_0
clear t_4D_grid_1
clear t_4D_grid_2
clear t_4D_grid_3
clear t_4D_grid_4
clear t_4D_grid_5
clear t_4D_grid_6
clear t_4D_grid_7
clear t_4D_grid_8
clear range
clear svar
clear cut4

