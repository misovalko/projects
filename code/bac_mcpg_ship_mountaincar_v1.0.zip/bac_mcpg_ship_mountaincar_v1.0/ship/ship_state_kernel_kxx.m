function kxx= ship_state_kernel_kxx( state, domain_params )
kxx = ship_state_kernel_kx(state,state,domain_params);
end

