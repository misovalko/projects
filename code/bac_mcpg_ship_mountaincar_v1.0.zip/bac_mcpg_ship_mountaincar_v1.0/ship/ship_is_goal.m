function state = ship_is_goal(state,domain_params)

x_goal = domain_params.X_INIT + domain_params.DELTA_X;
y_goal = domain_params.Y_INIT + domain_params.DELTA_Y;
x = state.x;
y = state.y;

state.isgoal = false;
state.success = false;

%%
if (x < domain_params.X_MIN || x > domain_params.X_MAX)
    state.isgoal = true;
    state.success = false;
end
%%
if (y < domain_params.Y_MIN || y > domain_params.Y_MAX)
    state.isgoal = true;
    state.success = false;
end
%%

tmp = sqrt((x - x_goal)^2 + (y - y_goal)^2);

if (tmp < domain_params.THR)
    state.isgoal = true;
    state.success = true;
end
