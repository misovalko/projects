function state = ship_random_state(domain_params)
state = [];
state.x = domain_params.X_INIT;     
state.y = domain_params.Y_INIT;   
state.V = 3;
state.T = 5;
state.theta = (rand() * (range(3,2) - range(3,1))) + range(3,1); 
state.dot_theta = (rand() * (range(4,2) - range(4,1))) + range(4,1);
state.isgoal = 0;
end