function ship_draw(state,domain_params,out)

if isempty(out) 
    state.success = -1;
    state.done = -1;
end


% figure(1)
clf
img_size = 30;
img_rotated = imrotate(domain_params.ship_image,state.theta,'bicubic','loose');
img_rotated(img_rotated==0) = 255;

imagesc([state.x-img_size/2,state.x+img_size/2],...
    [state.y-img_size/2,state.y+img_size/2], ...
    img_rotated);

set(gca,'YDir','normal');
axis([domain_params.X_MIN domain_params.X_MAX domain_params.Y_MIN domain_params.Y_MAX])


text(5, 5, sprintf('x: %f', state.x));
text(5, 15, sprintf('y: %f', state.y));
text(5, 25, sprintf('\\theta: %f', state.theta),'interpreter','tex');
text(5, 35, sprintf('d\\theta: %f', state.dot_theta),'interpreter','tex');

if  isfield(out,'reward1'), text(5, 45, sprintf('r1: %f', out.reward1)); end
if  isfield(out,'reward2'),text(5, 55, sprintf('r2: %f', out.reward2)); end
if  isfield(out,'reward'), text(5, 65, sprintf('r: %f', out.reward)); end

drawnow