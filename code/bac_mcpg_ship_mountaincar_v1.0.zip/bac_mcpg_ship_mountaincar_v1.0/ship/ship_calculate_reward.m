function [reward out] = ship_calculate_reward(state,~,domain_params)
%% calculate reward

x = state.x;
y = state.y;
theta = state.theta;
V = state.V;
success = state.success;
isgoal = state.isgoal;

if (isgoal == true && success == true)
    reward = domain_params.GOOD;
    out.reward = reward;
    return
elseif (isgoal == true && success == false)    
    reward = domain_params.BAD;
    out.reward = reward;
    return
else
    reward1 = domain_params.NUTRAL;
end

x_goal = domain_params.X_INIT + domain_params.DELTA_X;
y_goal = domain_params.Y_INIT + domain_params.DELTA_Y;

ang = (theta * pi) / 180;
x_new = x + (domain_params.DELTA_T * V * sin(ang));
y_new = y + (domain_params.DELTA_T * V * cos(ang));


ang1 = atan2((y - y_goal), (x - x_goal));
ang2 = atan2((y - y_new),(x - x_new));
ang = (domain_params.S_THETA * pi) / 180;
tmp = ((ang1 - ang2)^2) / (ang^2);
reward2 = exp(-tmp) - 1;

reward = reward1;
out.reward = reward;
out.reward1 = reward1;
out.reward2 = reward2;

return
