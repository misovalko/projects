function domain_params = ship_create_domain
domain_params = [];

domain_params.name = 'ship';
domain_params.dynamics = @ship_dynamics;
domain_params.random_state = @ship_random_state;
domain_params.calc_score = @ship_calc_score;
domain_params.perf_eval = @ship_perf_eval;
domain_params.calculate_reward = @ship_calculate_reward;
domain_params.is_goal = @ship_is_goal;

domain_params.state_kernel_kx = @ship_state_kernel_kx; 
domain_params.state_kernel_kxx = @ship_state_kernel_kxx;

domain_params.dt = 0.2;
domain_params.DELTA_T = 0.2;

% /********** Reward **********/
domain_params.GOOD=100;
domain_params.NUTRAL=-1;
domain_params.BAD=-100;
% /***** Reward Parameters *****/
domain_params.THR=10;
domain_params.S_THETA=30;
% /****** Variable Range ******/
domain_params.X_MIN=0;
domain_params.X_MAX=150;
domain_params.Y_MIN=0;
domain_params.Y_MAX=150;
domain_params.THETA_MIN=-180;
domain_params.THETA_MAX=180;
domain_params.DOT_THETA_MIN=-15;
domain_params.DOT_THETA_MAX=15;
% /******* Maximum Input *******/
domain_params.R_MAX=15;
% /****** Initial Values ******/
domain_params.X_INIT=40;
domain_params.Y_INIT=40;
domain_params.DELTA_X=100;
domain_params.DELTA_Y=100;

domain_params.W0=0;
domain_params.Z0=0;
% /****** Model Parameters ******/
domain_params.STEP = 3;
domain_params.DIM = 4;


domain_params.ship_image = imread('ship.png', 'BackgroundColor',[1 1 1]);

% close all
% figure(1)
% set(gca, 'color', [1 1 1])
% colordef white
% clf

end