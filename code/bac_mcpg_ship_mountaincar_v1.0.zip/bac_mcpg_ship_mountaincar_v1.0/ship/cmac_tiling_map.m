function vout = cmac_tiling_map(vin,tiling_set,svar)

vout(numel(tiling_set),1) = struct('tnum',[],'tindex',[]);

for i=1:numel(tiling_set)
    vec_size = svar(i,1);
    v = zeros(vec_size,1);
           
    for j=1:vec_size
        v(j) = vin(svar(i,j+1)); 
    end
    
    index = cmac_get_index(tiling_set(i),v);
    
    if (index ~= -1)
        if(index < 0 || index >= prod(tiling_set(i).cut))
            fprintf(1, 'features error : tiling %d, tile index = %d out of range\n', i, index);
            error('exit');
        end
        if(isempty(index))
            fprintf(1, 'features error: index NaN\n');
            error('exit');
        end
        vout(i).tnum = i;
        vout(i).tindex = index;        
    end
end
