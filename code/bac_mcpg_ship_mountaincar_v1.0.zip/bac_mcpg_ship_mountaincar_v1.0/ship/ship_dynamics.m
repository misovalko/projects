function [nstate,out] = ship_dynamics(state,r,domain_params)
% perform state transition for ship steering environament

% INPUT
%  state: state in what ship is in
%     double x;         //--- x coordinate of the ship (m)
%     double y;         //--- y coordinate of the ship (m)
%     double theta;     //--- orientation of the ship  (degrees)
%     double _theta;    //--- turning rate of the ship (degrees/sec)
%     double V;         //--- constant speed of ship (m/sec)
%     double T;         //--- time constant of convergence to desired turning rate
%  r: action, angle -15 to 15 degrees
%  domain_params:
%     dt: turning rate

%% initialization

out = [];
out.reward1 = 0;
out.reward2 = 0;
dt = domain_params.dt;

x = state.x;
y = state.y;
theta = state.theta;
dot_theta = state.dot_theta;
V = state.V;
T = state.T;

success = false;
isgoal = false;

%%

x_old = x;     y_old = y;
ang = (theta * pi) / 180;
x = x_old + (dt * V * sin(ang));
y = y_old + (dt * V * cos(ang));


theta = theta + (dt * dot_theta);

if (theta < 0)
    while (theta < domain_params.THETA_MIN)
        theta = theta + 360;
    end
end

if (theta > 0)
    while (theta > domain_params.THETA_MAX)
        theta = theta - 360;
    end
end

dot_theta = dot_theta + ((dt * (r - dot_theta)) / T);
if (dot_theta > domain_params.R_MAX)
    dot_theta = domain_params.R_MAX;
elseif (dot_theta < -domain_params.R_MAX)
    dot_theta = -domain_params.R_MAX;
end


%% output variables

nstate.x = x;
nstate.y = y;
nstate.theta = theta;
nstate.dot_theta = dot_theta;
nstate.V = V;
nstate.T = T;
nstate.success = success;
nstate.isgoal = isgoal;
