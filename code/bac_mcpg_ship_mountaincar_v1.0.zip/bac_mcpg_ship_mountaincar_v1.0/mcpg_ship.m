% setup for ship domain using MCPG
%
% @article{ghavamzadeh2016bayesian,
% abstract = {Policy gradient methods are reinforcement learning algorithms that adapt a parameterized policy by following a performance gradient estimate. Many conventional policy gradient methods use Monte-Carlo techniques to estimate this gradient. The policy is improved by adjusting the parameters in the direction of the gradient estimate. Since Monte-Carlo methods tend to have high variance, a large number of samples is required to attain accurate estimates, resulting in slow convergence. In this paper, we first propose a Bayesian framework for policy gradient, based on modeling the policy gradient as a Gaussian process. This reduces the number of samples needed to obtain accurate gradient estimates. Moreover, estimates of the natural gradient as well as a measure of the uncertainty in the gradient estimates, namely, the gradient covariance, are provided at little extra cost. Since the proposed Bayesian framework considers system trajectories as its basic observable unit, it does not require the dynamics within trajectories to be of any particular form, and thus, can be easily extended to partially observable problems. On the downside, it cannot take advantage of the Markov property when the system is Markovian. To address this issue, we proceed to supplement our Bayesian policy gradient framework with a new actor-critic learning model in which a Bayesian class of non-parametric critics, based on Gaussian process temporal difference learning, is used. Such critics model the action-value function as a Gaussian process, allowing Bayes' rule to be used in computing the posterior distribution over action-value functions, conditioned on the observed data. Appropriate choices of the policy parameterization and of the prior covariance (kernel) between action-values allow us to obtain closed-form expressions for the posterior distribution of the gradient of the expected return with respect to the policy parameters. We perform detailed experimental comparisons of the proposed Bayesian policy gradient and actor-critic algorithms with classic Monte-Carlo based policy gradient methods, as well as with each other, on a number of reinforcement learning problems.},
% author = {Ghavamzadeh, Mohammad and Engel, Yaakov and Valko, Michal},
% journal = {Journal of Machine Learning Research},
% title = {{Bayesian policy gradient and actor-critic algorithms}},
% year = {2016}
% }



addpath ship
domain_params = ship_create_domain;
domain_params.num_episode_eval = 100;

learning_params = [];
learning_params.episode_len_max = 500; 
learning_params.num_episode = 10;
learning_params.sample_interval = 100; %10;
learning_params.num_update_max = 3000;% 1000; %250; %25000;
learning_params.gam = 0.95; %%0.95;
% MC
learning_params.alp_init_MC = 0.01;
learning_params.num_trial = 10;
learning_params.SIGMA_INIT=1;
learning_params.theta_max = 100;

ship_tiling_setup

learning_params.other_name =  ...
    sprintf('MCPG alpha %4.2f numepisodes %d sample %d max %d', ...
    learning_params.alp_init_MC,learning_params.num_episode,...
    learning_params.sample_interval,learning_params.num_update_max);

[perf, theta] = mcpg(domain_params,learning_params);

fid1 = fopen('results/perf_SHIP_mountain_car.txt','w');
for tt = 1:size(perf,2)
     fprintf(fid1,'%f %f \n',mean(perf(:,tt)),std(perf(:,tt)));
end
fclose(fid1);
