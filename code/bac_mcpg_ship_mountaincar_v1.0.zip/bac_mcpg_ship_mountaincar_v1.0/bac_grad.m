% @article{ghavamzadeh2016bayesian,
% abstract = {Policy gradient methods are reinforcement learning algorithms that adapt a parameterized policy by following a performance gradient estimate. Many conventional policy gradient methods use Monte-Carlo techniques to estimate this gradient. The policy is improved by adjusting the parameters in the direction of the gradient estimate. Since Monte-Carlo methods tend to have high variance, a large number of samples is required to attain accurate estimates, resulting in slow convergence. In this paper, we first propose a Bayesian framework for policy gradient, based on modeling the policy gradient as a Gaussian process. This reduces the number of samples needed to obtain accurate gradient estimates. Moreover, estimates of the natural gradient as well as a measure of the uncertainty in the gradient estimates, namely, the gradient covariance, are provided at little extra cost. Since the proposed Bayesian framework considers system trajectories as its basic observable unit, it does not require the dynamics within trajectories to be of any particular form, and thus, can be easily extended to partially observable problems. On the downside, it cannot take advantage of the Markov property when the system is Markovian. To address this issue, we proceed to supplement our Bayesian policy gradient framework with a new actor-critic learning model in which a Bayesian class of non-parametric critics, based on Gaussian process temporal difference learning, is used. Such critics model the action-value function as a Gaussian process, allowing Bayes' rule to be used in computing the posterior distribution over action-value functions, conditioned on the observed data. Appropriate choices of the policy parameterization and of the prior covariance (kernel) between action-values allow us to obtain closed-form expressions for the posterior distribution of the gradient of the expected return with respect to the policy parameters. We perform detailed experimental comparisons of the proposed Bayesian policy gradient and actor-critic algorithms with classic Monte-Carlo based policy gradient methods, as well as with each other, on a number of reinforcement learning problems.},
% author = {Ghavamzadeh, Mohammad and Engel, Yaakov and Valko, Michal},
% journal = {Journal of Machine Learning Research},
% title = {{Bayesian policy gradient and actor-critic algorithms}},
% year = {2016}
% }

function grad = bac_grad(episodes,G,domain_params,learning_params)

gam = learning_params.gam;
gam2 = gam^2;

nu = 0.1;
sig = 3;
sig2 = sig^2;
ck_xa = 1;
sigk_x = 1.3 * 0.25;   


% GLOBAL INITIALIZATION
T = 0;
m = 0;
statedic = [];
scr_dic = [];
invG_scr_dic = [];
alpha = [];
C = [];
Kinv = [];
k = [];
c = [];
z = [];

for l = 1:learning_params.num_episode    
%%%%%%%%%%%% INIT. PER TRIAL %%%%%%%%%%%%

    ISGOAL = 0;
    t = 1;
    T = T + 1;
    c = zeros(m,1);
    d = 0;
    s = inf;

    state = episodes{l,1}(:,t);
    scr = episodes{l,2}(:,t);

    temp1 = domain_params.state_kernel_kxx(state,domain_params);
    invG_scr = G\scr;
    
    temp2 = ck_xa * (scr' * invG_scr);
    kk = temp1 + temp2;

    if (m > 0)     
        
        k = ck_xa * (scr' * invG_scr_dic); % state-action kernel - fisherinformation kernel
        k = (k + domain_params.state_kernel_kx(state,statedic,domain_params))';
        
        a = Kinv * k;
        delta = kk - (k' * a);
    else
        k = [];
        a = [];
        delta = kk;
    end

    if ((m == 0) || (delta > nu))
        a_hat = a;
        h = [a; -gam];
        a = [z; 1];
        alpha = [alpha; 0];
        C = [C, z; z', 0];        
        Kinv = [(delta * Kinv) + (a_hat * a_hat'), -a_hat;
                -a_hat'                          , 1] / delta;
        z = [z; 0];
        c = [c; 0];
        statedic = [statedic, state];
        scr_dic = [scr_dic, scr];
        invG_scr_dic = [invG_scr_dic, invG_scr];        
        m = m + 1;
        k = [k; kk];
    end

%%%%%%%%%%%% END INITIALIZE %%%%%%%%%%%%

%%%%%%%%%%%% TIME LOOP %%%%%%%%%%%%%

    while (t < episodes{l,3})
        state_old = state;
        k_old = k;
        kk_old = kk;
        a_old = a;
        c_old = c;
        s_old = s;
        d_old = d;
      
        r =  domain_params.calculate_reward(state_old,-1,domain_params);        
        
        coef = (gam * sig2) / s_old;

        if (ISGOAL == 1)   %%%%%%%%%%%% GOAL UPDATE %%%%%%%%%%%%
            dk = k_old;
            dkk = kk_old;
            h = a_old;
            c = (coef * c_old) + h - (C * dk);
            s = sig2 - (gam * sig2 * coef) + (dk' * (c + (coef * c_old)));
            d = (coef * d_old) + r - (dk' * alpha);
        else   %%%%%%%%%%%% NON-GOAL UPDATE %%%%%%%%%%%% 
            state = episodes{l,1}(:,t+1);
            scr = episodes{l,2}(:,t+1);
            
            if (state.isgoal)
                ISGOAL = 1;
                t = t - 1;
                T = T - 1;
            end
            
            
            temp1 = domain_params.state_kernel_kxx(state,domain_params);
              invG_scr  =  G\scr;
            temp2 = ck_xa * (scr' * invG_scr); 
            kk = temp1 + temp2;
            
            k = ck_xa * (scr' * invG_scr_dic);
            k = (k + domain_params.state_kernel_kx(state,statedic,domain_params))';
            
            a = Kinv * k;
            delta = kk - (k' * a);

            dk = k_old - (gam * k);
            d = (coef * d_old) + r - (dk' * alpha);
            
            if (delta > nu)   %%%%%%%%%% DELTA > NU %%%%%%%%%%
                h = [a_old; -gam];
                dkk = (a_old' * (k_old - (2 * gam * k))) + (gam2 * kk);
                c = (coef * [c_old; 0]) + h - [C * dk; 0];
                s = ((1 + gam2) * sig2) + dkk - (dk' * C * dk) + (2 * coef * c_old' * dk) - (gam * sig2 * coef);
                alpha = [alpha; 0];
                C = [C, z; z', 0];
                statedic = [statedic, state];
                scr_dic = [scr_dic, scr];
                invG_scr_dic = [invG_scr_dic, invG_scr];
                m = m + 1;
                Kinv = [(delta * Kinv) + (a * a'), -a;
                        -a'                      , 1] / delta;
                a = [z; 1];
                z = [z; 0];
                k = [k; kk];
            else   %%%%%%%%%% DELTA <= NU %%%%%%%%%%
                h = a_old - (gam * a);
                dkk = h' * dk;
                c = (coef * c_old) + h - (C * dk);
                s = ((1 + gam2) * sig2) + (dk' * (c + (coef * c_old))) - (gam * sig2 * coef);
            end % if delta
        end % if goal
        
        % alpha update
        alpha = alpha + (c * (d / s));
        % C update
        C = C + (c * (c' / s));
        
        % update time counters
        t = t + 1;
        T = T + 1;
    end % while t
end % for trial

grad = ck_xa * (scr_dic * alpha);

return